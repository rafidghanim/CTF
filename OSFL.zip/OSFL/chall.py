import sys

def exit_program():
    print("Jawaban salah. Program dihentikan.")
    sys.exit()

print("DISINI SAYA MENGGUNAKAN CHANGE CASE YAITU CAPITALIZE EACH WORD")
print("---------- CHALL MISCELLANEOUS INI ADA 10 PERTANYAAN ----------")
print("--------------- BANTU SAYA MENDAPATKAN FLAG NYA ---------------")

print("\nINI LINK CHALLENGE PERTAMA")
print("link drive = https://drive.google.com/file/d/1lCgU34P1mKGmkvfgssuV6uah2mzLBBtD/view?usp=sharing")
print("FORMAT = Wisata Yang Kamu Ketahui")
chall1 = input("Masukkan Sesuai Format = ")
if chall1 != "Taman Mini Indonesia Indah":
    exit_program()

print("\nINI LINK CHALLENGE KEDUA")
print("link drive = https://drive.google.com/file/d/1pFxDVkvEdQsqYrRzIpSVWiRhA-u6Qoh-/view?usp=sharing")
print("FORMAT = Nama Tempat Nya_Nama Kabupaten_Nama Provinsi_Kodepos")
chall2 = input("Masukkan Sesuai Format = ")
if chall2 != "Lanud Atang Sendjaja_Kabupaten Bogor_Jawa Barat_16310":
    exit_program()

print("\nINI LINK CHALLENGE KETIGA")
print("link drive = https://drive.google.com/file/d/1jJFzRXIvIyTNJaWAgAPEHZaHzNgneaXv/view?usp=sharing")
print("FORMAT = Nama Tempat Aja")
chall3 = input("Masukkan Sesuai Format = ")
if chall3 != "Gelora Bung Karno":
    exit_program()

print("\nINI LINK CHALLENGE KEEMPAT")
print("link drive = https://drive.google.com/file/d/1Lsc-sAnE-LIAWDGCcg5sJovSmCQegTIs/view?usp=sharing")
print("FORMAT = Nama Mall_KodePos")
chall4 = input("Masukkan Sesuai Format = ")
if chall4 != "Kuningan City_12940":
    exit_program()

print("\nINI LINK CHALLENGE KELIMA")
print("link drive = https://drive.google.com/file/d/1zXYHhU7JgQLTZo34WT6Avea4XYTPLa7G/view?usp=sharing")
print("FORMAT = Nama Tempat_Kodepos")
chall5 = input("Masukkan Sesuai Format = ")
if chall5 != "Starbucks Kelapadua_16451":
    exit_program()

print("\nINI LINK CHALLENGE KEENAM")
print("link drive = https://drive.google.com/file/d/1-odRAbxyIcBtipRBYkcNe_G4C1eUBU1d/view?usp=sharing")
print("FORMAT = Nama Tempat Nya Apa_Kodepos")
chall6 = input("Masukkan Sesuai Format = ")
if chall6 != "Pusdiklat Bela Negara Kemhan_16350":
    exit_program()

print("\nINI LINK CHALLENGE KETUJUH")
print("link drive = https://drive.google.com/file/d/1oY5MUywIo9Gv2GvO97ndoKn-Lr4jjX7t/view?usp=sharing")
print("FORMAT = Nama Tempat 0")
chall7 = input("Masukkan Sesuai Format = ")
if chall7 != "Ashta Disctrict 8":
    exit_program()

print("\nINI LINK CHALLENGE KEDELAPAN")
print("link drive = https://drive.google.com/file/d/1hYTN80kasAvhIPz9T1mqAUd9umW2IwwD/view?usp=drive_link")
print("FORMAT = Nama Universitas")
chall8 = input("Masukkan Sesuai Format = ")
if chall8 != "Universitas Bakrie":
    exit_program()

print("\nINI LINK CHALLENGE KESEMBILAN")
print("link drive = https://drive.google.com/file/d/1pZiUZ7P53FvwUXUwBwzMsBxDMrDSNMVO/view?usp=drive_link")
print("FORMAT = Nama Stasiun")
chall9 = input("Masukkan Sesuai Format = ")
if chall9 != "Pondok Cina":
    exit_program()

print("\nINI LINK CHALLENGE KESEPULUH")
print("link drive = https://drive.google.com/file/d/1VrapBjFC0ncJ_sLFJIQoYQjJlsWO9tBO/view?usp=drive_link")
print("FORMAT = Ini Nama Kampus Apa")
chall10 = input("Masukkan Sesuai Format = ")
if chall10 != "Universitas Gunadarma Kampus D":
    exit_program()

print("\nSemua jawaban benar!")
print("Ini Adalah Flag Nya Kawan = NEXUS{m1sc3ll4ne0u5_cHa4lll_FInal_YanG_CuKuP_BanYaakkk_DaN_R1B3T}")
