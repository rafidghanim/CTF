<?php
$conn = mysqli_connect("localhost", "ctf", "ACT_CTF{thisis_fakeFlag}", "ACT");

